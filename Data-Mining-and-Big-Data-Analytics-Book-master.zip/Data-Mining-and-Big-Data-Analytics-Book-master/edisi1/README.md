## Repositori ini adalah untuk buku edisi 1.
1. Bagi para pembeli buku Edisi 1, akan mendapatkan hak akses online dari materi yang ditambahkan pada buku Edisi 2, yaitu mengenai deep learning, atau lebih khususnya convolutional neural network (CNN). Untuk mendapatkan hak akses online tersebut, silakan mengirimkan pesan ke: bukukita.indo@gmail.com beserta dengan bukti foto buku yang telah dibeli. 
